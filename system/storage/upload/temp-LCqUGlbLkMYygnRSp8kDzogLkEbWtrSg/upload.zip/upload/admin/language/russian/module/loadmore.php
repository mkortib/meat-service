<?php
// Heading
$_['heading_title']     = 'Ajax Product Page Loader by <a href="https://opencartforum.com/index.php?app=core&module=search&do=user_activity&search_app=downloads&mid=11962">Wadamir</a>';

// Text
$_['text_module']       = 'Модули';
$_['text_success']      = 'Отлично! Вы успешно отредактировали модуль "Ajax Product Page Loader"!';
$_['text_edit']         = 'Редактировать модуль "Ajax Product Page Loader"';

// Entry
$_['loadmore_button_name'] 			= 'Загрузить ешё';
$_['loadmore_button_name_title'] 	= 'Текст на кнопке';
$_['loadmore_style_title'] 			= 'CSS стили для кнопки';
$_['loadmore_default_style_title'] 	= 'CSS стили по умолчанию';
$_['loadmore_arrow_status_title'] 	= 'Показывать стрелочку "наверх"';
$_['loadmore_status_title'] 		= 'Статус';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify "Ajax Product Page Loader" module!';