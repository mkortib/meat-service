<?php
// Heading
$_['heading_title'] = 'Cache remove';

// Text
$_['text_cacheremove'] = 'Cache';
$_['text_extension'] = 'Extensions';
$_['text_data'] = 'Data Cache:';
$_['text_image'] = 'Image Cache:';
$_['text_author'] = 'Author';
$_['text_author_support'] = 'Support';

$_['btn_clear'] = 'Clear';

$_['text_success'] = 'Successfully remove your cache';
$_['text_error_files'] = 'Can\'t delete files:';
