<?php

// Heading
$_['heading_title'] = 'Очистка кэша';

// Text
$_['text_cacheremove'] = 'Кэш';
$_['text_extension'] = 'Расширения';
$_['text_data']	= 'Кэш данных:';
$_['text_image'] = 'Кэш изображений:';
$_['text_author'] = 'Автор';
$_['text_author_support'] = 'Поддержка';

$_['btn_clear'] = 'Очистить';

$_['text_success'] = 'Кэш очищен!';
$_['text_error_files'] = 'Не получилось удалить следующие файлы:';