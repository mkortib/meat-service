<?php

// Heading
$_['heading_title'] = 'Очищення кешу';

// Text
$_['text_cacheremove'] = 'Кеш';
$_['text_extension'] = 'Розширення';
$_['text_data'] = 'Кеш даних:';
$_['text_image'] = 'Кэш зображень:';
$_['text_author'] = 'Автор';
$_['text_author_support'] = 'Підтримка';

$_['btn_clear'] = 'Очистити';

$_['text_success'] = 'Кэш очищений!';
$_['text_error_files'] = 'Не вдалося видалити такі файли:';
